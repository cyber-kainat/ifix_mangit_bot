"""
Bot konfiguratsiyasi
"""
import os
from dataclasses import dataclass


@dataclass
class Config:
    # Telegram bot tokeni - @BotFather dan oling
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
    
    # Admin Telegram ID raqamlari (ro'yxat - bir nechta admin bo'lishi mumkin)
    # O'z ID raqamingizni @userinfobot dan oling
    ADMIN_IDS: list = None
    
    # Ma'lumotlar bazasi nomi
    DB_NAME: str = "shop.db"
    
    # To'lov ma'lumotlari (Click va Payme uchun kartalar)
    CLICK_CARD: str = "8600 1234 5678 9012"
    CLICK_OWNER: str = "Aliyev Ali"
    PAYME_CARD: str = "8600 9876 5432 1098"
    PAYME_OWNER: str = "Aliyev Ali"
    
    # Do'kon manzili (naqd to'lov uchun)
    SHOP_ADDRESS: str = "Toshkent sh., Chilonzor tumani, 1-mavze"
    SHOP_PHONE: str = "+998 90 123 45 67"
    
    def __post_init__(self):
        if self.ADMIN_IDS is None:
            # Vergul bilan ajratilgan admin ID lar: "123456,789012"
            admin_str = os.getenv("ADMIN_IDS", "123456789")
            self.ADMIN_IDS = [int(x.strip()) for x in admin_str.split(",") if x.strip()]


config = Config()
